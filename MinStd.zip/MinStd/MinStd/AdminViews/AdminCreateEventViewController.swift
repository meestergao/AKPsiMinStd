//
//  ViewController.swift
//  MinStd
//
//  Created by Chris Gao on 1/31/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import FirebaseDatabase

var shifts = [String]()

class AdminCreateEventViewController: UIViewController,UITextFieldDelegate{
    
    //VARIABLES
    var ref:DatabaseReference?
    let eventCat = ["Professionalism", "Philanthropy", "Fundraising", "Advancement", "Miscellaneous"]
    let eventCap = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    let eventAMPM = ["AM", "PM"]
    var selectedCat: String?
    var selectedTime: String?
    var selectedAMPM: String?
    private var datePicker: UIDatePicker?
    private var startTimePicker: UIDatePicker?
    private var endTimePicker: UIDatePicker?
    
    //OUTLETS
    @IBOutlet weak var eventCategoryText: UITextField!
    @IBOutlet weak var eventTitleText: UITextField!
    @IBOutlet weak var eventStartTimeText: UITextField!
    @IBOutlet weak var eventEndTimeText: UITextField!
    @IBOutlet weak var eventDate: UITextField!
    @IBOutlet weak var eventShiftCap: UITextField!
    
    //CREATE BUTTON
    @IBAction func createEventButton(_ sender: Any){
        let dialogMessage = UIAlertController(title: "Confirm", message: "Create new event?", preferredStyle: .alert)
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
            //ADD EVENT
            let newEvent = ["Category": self.eventCategoryText.text!,"Date": self.eventDate.text!,"Start Time": self.eventStartTimeText.text!,"End Time": self.eventEndTimeText.text!,"Shift Cap": self.eventShiftCap.text!, "Shifts": ""]
            self.ref?.child("Events").child(self.eventTitleText.text!).setValue(newEvent)
            
            //CREATE LIST OF SHIFTS
            var counter = 0
            shifts.removeAll()
            
            while counter < self.calcNumShifts(startTime: self.eventStartTimeText.text!, endTime: self.eventEndTimeText.text!)
            {
                //WRITE TIME LABELS FOR CELLS HERE
                var startAM = true
                var endAM = true
                var startTime = self.convertTime(time: self.eventStartTimeText.text!) + counter
                var endTime = startTime + 1
                if startTime >= 12
                {
                    if startTime > 12
                    {
                        startTime = startTime - 12
                    }
                    startAM = false
                }
                if endTime >= 12
                {
                    if endTime > 12
                    {
                        endTime = endTime - 12
                    }
                    endAM = false
                }
                var shiftStart = String(startTime) + ":00"
                var shiftEnd = String(endTime) + ":00"
                if startAM
                {
                    shiftStart = shiftStart + " AM"
                }
                else
                {
                    shiftStart = shiftStart + " PM"
                }
                if endAM{
                    shiftEnd = shiftEnd + " AM"
                }
                else
                {
                    shiftEnd = shiftEnd + " PM"
                }
                shifts.append(shiftStart + " - " + shiftEnd)
                counter += 1
            }
            for x in shifts{
                self.ref?.child("Events").child(self.eventTitleText.text!).child("Shifts").child(x).setValue("0 / " + self.eventShiftCap.text!)
            }
            self.eventCategoryText.text = ""
            self.eventTitleText.text = ""
            self.eventDate.text = ""
            self.eventStartTimeText.text = ""
            self.eventEndTimeText.text = ""
            self.eventShiftCap.text = ""
        })
        // Create Cancel button with action handlder
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        //Add OK and Cancel button to dialog message
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        // Present dialog message to user
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    //VIEW LOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //FIREBASE REFERENCE
        ref = Database.database().reference()
        
        //DATE PICKER
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action: #selector(AdminCreateEventViewController.dateChanged(datePicker:)), for: .valueChanged)
        eventDate.inputView = datePicker
        
        //TIME PICKER
        startTimePicker = UIDatePicker()
        startTimePicker?.datePickerMode = .time
        startTimePicker?.addTarget(self, action: #selector(AdminCreateEventViewController.startTimeChanged(timePicker:)), for: .valueChanged)
        eventStartTimeText.inputView = startTimePicker
        
        //TIME PICKER
        endTimePicker = UIDatePicker()
        endTimePicker?.datePickerMode = .time
        endTimePicker?.addTarget(self, action: #selector(AdminCreateEventViewController.endTimeChanged(timePicker:)), for: .valueChanged)
        eventEndTimeText.inputView = endTimePicker
        
        //OTHER PICKERS
        createPicker(IBOutlet: eventCategoryText, Tag: 1)
        createPicker(IBOutlet: eventShiftCap, Tag: 2)
        createToolbar()
    }
    
    func calcNumShifts(startTime: String, endTime: String) -> Int
    {
        return convertTime(time: endTime) - convertTime(time: startTime)
    }
    
    //Function to convert time to 24 hr Integer
    func convertTime(time: String) -> Int
    {
        var tempTime = ""
        var intTime = 0
        for x in time
        {
            if x == ":"
            {
                intTime = Int(tempTime)!
                break
            }
            else
            {
                tempTime = tempTime + String(x)
            }
        }
        if time.contains("PM") && intTime != 12
        {
            intTime = intTime + 12
        }
        return intTime
    }
    
    @objc func dateChanged(datePicker: UIDatePicker){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        eventDate.text = dateFormatter.string(from: datePicker.date)
    }
    
    @objc func startTimeChanged(timePicker: UIDatePicker){
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "hh:mm a"
        eventStartTimeText.text = timeFormatter.string(from: timePicker.date)
    }
    
    @objc func endTimeChanged(timePicker: UIDatePicker){
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "hh:mm a"
        eventEndTimeText.text = timeFormatter.string(from: timePicker.date)
    }

    //DROP DOWN MENU
    func createPicker(IBOutlet: UITextField, Tag: Int) {
        let picker = UIPickerView()
        picker.tag = Tag
        picker.delegate = self
        IBOutlet.inputView = picker
        picker.backgroundColor = .clear
    }
    //DONE BUTTON ON DROP DOWN MENU
    func createToolbar(){
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(AdminCreateEventViewController.dismissKeyboard))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        eventCategoryText.inputAccessoryView = toolBar
        eventStartTimeText.inputAccessoryView = toolBar
        eventEndTimeText.inputAccessoryView = toolBar
        eventDate.inputAccessoryView = toolBar
        eventShiftCap.inputAccessoryView = toolBar
        //CUSTOMIZATIONS
        toolBar.barTintColor = .black
        toolBar.tintColor = .white
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    //MISC
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        eventTitleText.resignFirstResponder()
        eventStartTimeText.resignFirstResponder()
        eventCategoryText.resignFirstResponder()
        eventEndTimeText.resignFirstResponder()
        eventDate.resignFirstResponder()
        eventShiftCap.resignFirstResponder()
    }
}

extension AdminCreateEventViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (pickerView.tag == 1){
            return eventCat.count
        }
        else if (pickerView.tag == 2){
            return eventCap.count
        }
        else{
            return 0
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (pickerView.tag == 1){
            return eventCat[row]
        }
        else if (pickerView.tag == 2){
            return eventCap[row]
        }
        else{
            return eventCat[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.tag == 1){
            eventCategoryText.text = eventCat[row]
        }
        else if (pickerView.tag == 2){
            eventShiftCap.text = eventCap[row]
        }
    }
}
