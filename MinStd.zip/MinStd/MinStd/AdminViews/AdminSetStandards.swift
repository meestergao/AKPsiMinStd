//
//  AdminSetStandards.swift
//  MinStd
//
//  Created by Chris Gao on 5/6/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AdminSetStandards: UIViewController {

    //OUTLETS
    @IBOutlet weak var bronzeProf: UITextField!
    @IBOutlet weak var bronzePhil: UITextField!
    @IBOutlet weak var bronzeAdv: UITextField!
    @IBOutlet weak var bronzeFund: UITextField!
    @IBOutlet weak var bronzeExtra: UITextField!
    @IBOutlet weak var silverProf: UITextField!
    @IBOutlet weak var silverPhil: UITextField!
    @IBOutlet weak var silverAdv: UITextField!
    @IBOutlet weak var silverFund: UITextField!
    @IBOutlet weak var silverExtra: UITextField!
    @IBOutlet weak var goldProf: UITextField!
    @IBOutlet weak var goldPhil: UITextField!
    @IBOutlet weak var goldAdv: UITextField!
    @IBOutlet weak var goldFund: UITextField!
    @IBOutlet weak var goldExtra: UITextField!
    
    //VARIABLES
    let hoursList = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    
    @IBAction func setStandards(_ sender: Any) {
        let dialogMessage = UIAlertController(title: "Confirm", message: "Set new standards?", preferredStyle: .alert)
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
            self.ref = Database.database().reference()
            let bronzeStandards = ["Professionalism": self.bronzeProf.text!, "Philanthropy": self.bronzePhil.text!, "Advancement": self.bronzeAdv.text!, "Fundraising": self.bronzeFund.text!, "Extra": self.bronzeExtra.text!]
            let silverStandards = ["Professionalism": self.silverProf.text!, "Philanthropy": self.silverPhil.text!, "Advancement": self.silverAdv.text!, "Fundraising": self.silverFund.text!, "Extra": self.silverExtra.text!]
            let goldStandards = ["Professionalism": self.goldProf.text!, "Philanthropy": self.goldPhil.text!, "Advancement": self.goldAdv.text!, "Fundraising": self.goldFund.text!, "Extra": self.goldExtra.text!]
            self.ref?.child("Standards").child("Bronze").setValue(bronzeStandards)
            self.ref?.child("Standards").child("Silver").setValue(silverStandards)
            self.ref?.child("Standards").child("Gold").setValue(goldStandards)
        })
        // Create Cancel button with action handlder
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        //Add OK and Cancel button to dialog message
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        // Present dialog message to user
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //INITIALIZE VALUES
        ref = Database.database().reference()
        ref?.observeSingleEvent(of: .value, with: {(snapshot) in
            if snapshot.hasChild("Standards"){
                self.bronzeProf.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Professionalism").value as? String
                self.bronzePhil.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Philanthropy").value as? String
                self.bronzeAdv.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Advancement").value as? String
                self.bronzeFund.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Fundraising").value as? String
                self.bronzeExtra.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Extra").value as? String
                self.silverProf.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Silver").childSnapshot(forPath: "Professionalism").value as? String
                self.silverPhil.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Silver").childSnapshot(forPath: "Philanthropy").value as? String
                self.silverAdv.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Silver").childSnapshot(forPath: "Advancement").value as? String
                self.silverFund.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Silver").childSnapshot(forPath: "Fundraising").value as? String
                self.silverExtra.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Silver").childSnapshot(forPath: "Extra").value as? String
                self.goldProf.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Gold").childSnapshot(forPath: "Professionalism").value as? String
                self.goldPhil.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Gold").childSnapshot(forPath: "Philanthropy").value as? String
                self.goldAdv.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Gold").childSnapshot(forPath: "Advancement").value as? String
                self.goldFund.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Gold").childSnapshot(forPath: "Fundraising").value as? String
                self.goldExtra.text = snapshot.childSnapshot(forPath: "Standards").childSnapshot(forPath: "Gold").childSnapshot(forPath: "Extra").value as? String
            }
            else{
                self.initHours()
            }
        })
        //SETUP PICKERS
        createPicker(IBOutlet: bronzeProf, Tag: 1)
        createPicker(IBOutlet: bronzePhil, Tag: 2)
        createPicker(IBOutlet: bronzeAdv, Tag: 3)
        createPicker(IBOutlet: bronzeFund, Tag: 4)
        createPicker(IBOutlet: bronzeExtra, Tag: 5)
        createPicker(IBOutlet: silverProf, Tag: 6)
        createPicker(IBOutlet: silverPhil, Tag: 7)
        createPicker(IBOutlet: silverAdv, Tag: 8)
        createPicker(IBOutlet: silverFund, Tag: 9)
        createPicker(IBOutlet: silverExtra, Tag: 10)
        createPicker(IBOutlet: goldProf, Tag: 11)
        createPicker(IBOutlet: goldPhil, Tag: 12)
        createPicker(IBOutlet: goldAdv, Tag: 13)
        createPicker(IBOutlet: goldFund, Tag: 14)
        createPicker(IBOutlet: goldExtra, Tag: 15)
        createToolbar()
    }
    
    //INIT FIELDS TO 0
    func initHours(){
        bronzeProf.text = "0"
        bronzePhil.text = "0"
        bronzeAdv.text = "0"
        bronzeFund.text = "0"
        bronzeExtra.text = "0"
        silverProf.text = "0"
        silverPhil.text = "0"
        silverAdv.text = "0"
        silverFund.text = "0"
        silverExtra.text = "0"
        goldProf.text = "0"
        goldPhil.text = "0"
        goldAdv.text = "0"
        goldFund.text = "0"
        goldExtra.text = "0"
    }
    
    //DROP DOWN MENU
    func createPicker(IBOutlet: UITextField, Tag: Int) {
        let picker = UIPickerView()
        picker.tag = Tag
        picker.delegate = self
        IBOutlet.inputView = picker
        picker.backgroundColor = .clear
    }
    //DONE BUTTON ON DROP DOWN MENU
    func createToolbar(){
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(AdminCreateEventViewController.dismissKeyboard))
        toolBar.setItems([doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        bronzeProf.inputAccessoryView = toolBar
        bronzePhil.inputAccessoryView = toolBar
        bronzeAdv.inputAccessoryView = toolBar
        bronzeFund.inputAccessoryView = toolBar
        bronzeExtra.inputAccessoryView = toolBar
        silverProf.inputAccessoryView = toolBar
        silverPhil.inputAccessoryView = toolBar
        silverAdv.inputAccessoryView = toolBar
        silverFund.inputAccessoryView = toolBar
        silverExtra.inputAccessoryView = toolBar
        goldProf.inputAccessoryView = toolBar
        goldPhil.inputAccessoryView = toolBar
        goldAdv.inputAccessoryView = toolBar
        goldFund.inputAccessoryView = toolBar
        goldExtra.inputAccessoryView = toolBar
        //CUSTOMIZATIONS
        toolBar.barTintColor = .black
        toolBar.tintColor = .white
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    //MISC
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        bronzeProf.resignFirstResponder()
        bronzePhil.resignFirstResponder()
        bronzeAdv.resignFirstResponder()
        bronzeFund.resignFirstResponder()
        bronzeExtra.resignFirstResponder()
        silverProf.resignFirstResponder()
        silverPhil.resignFirstResponder()
        silverAdv.resignFirstResponder()
        silverFund.resignFirstResponder()
        silverExtra.resignFirstResponder()
        goldProf.resignFirstResponder()
        goldPhil.resignFirstResponder()
        goldAdv.resignFirstResponder()
        goldFund.resignFirstResponder()
        goldExtra.resignFirstResponder()
    }

}

extension AdminSetStandards: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return hoursList.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return hoursList[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.tag == 1){
            bronzeProf.text = hoursList[row]
        }
        else if (pickerView.tag == 2){
            bronzePhil.text = hoursList[row]
        }
        else if (pickerView.tag == 3){
            bronzeAdv.text = hoursList[row]
        }
        else if (pickerView.tag == 4){
            bronzeFund.text = hoursList[row]
        }
        else if (pickerView.tag == 5){
            bronzeExtra.text = hoursList[row]
        }
        else if (pickerView.tag == 6){
            silverProf.text = hoursList[row]
        }
        else if (pickerView.tag == 7){
            silverPhil.text = hoursList[row]
        }
        else if (pickerView.tag == 8){
            silverAdv.text = hoursList[row]
        }
        else if (pickerView.tag == 9){
            silverFund.text = hoursList[row]
        }
        else if (pickerView.tag == 10){
            silverExtra.text = hoursList[row]
        }
        else if (pickerView.tag == 11){
            goldProf.text = hoursList[row]
        }
        else if (pickerView.tag == 12){
            goldPhil.text = hoursList[row]
        }
        else if (pickerView.tag == 13){
            goldAdv.text = hoursList[row]
        }
        else if (pickerView.tag == 14){
            goldFund.text = hoursList[row]
        }
        else if (pickerView.tag == 15){
            goldExtra.text = hoursList[row]
        }
    }
}
