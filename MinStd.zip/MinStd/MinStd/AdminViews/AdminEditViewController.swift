//
//  AdminEditViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/25/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase

class AdminEditViewController: UIViewController {

    @IBAction func logOut(_ sender: Any) {
        try! Auth.auth().signOut()
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
