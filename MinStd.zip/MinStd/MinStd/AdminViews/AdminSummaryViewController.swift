//
//  AdminSummaryViewController.swift
//  MinStd
//
//  Created by Chris Gao on 5/7/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AdminSummaryViewController: UIViewController {
    //VARIABLES
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    //OUTLETS
    @IBOutlet weak var badStanding: UITextField!
    @IBOutlet weak var bronzeStanding: UITextField!
    @IBOutlet weak var silverStanding: UITextField!
    @IBOutlet weak var goldStanding: UITextField!
    @IBOutlet weak var advEvents: UITextField!
    @IBOutlet weak var fundEvents: UITextField!
    @IBOutlet weak var philEvents: UITextField!
    @IBOutlet weak var profEvents: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //SET FIREBASE REF AND VARIABLES
        var badCount = 0
        var bronzeCount = 0
        var silverCount = 0
        var goldCount = 0
        var advCount = 0
        var fundCount = 0
        var philCount = 0
        var profCount = 0
        ref = Database.database().reference()
        //DISPLAY NUMBER OF USERS PER STANDING
        databaseHandle = ref?.child("Users").observe(.value, with: { (snapshot) in
            for case let rest as DataSnapshot in snapshot.children{
                if (rest.childSnapshot(forPath: "Username").value as! String != "Admin"){
                    if (rest.childSnapshot(forPath: "Standing").value as? String == "Bad Standing"){
                        badCount += 1
                    }
                    else if (rest.childSnapshot(forPath: "Standing").value as? String == "Bronze Standing"){
                        bronzeCount += 1
                    }
                    else if (rest.childSnapshot(forPath: "Standing").value as? String == "Silver Standing"){
                        silverCount += 1
                    }
                    else if (rest.childSnapshot(forPath: "Standing").value as? String == "Gold Standing"){
                        goldCount += 1
                    }
                }
            }
            self.badStanding.text = String(badCount)
            self.bronzeStanding.text = String(bronzeCount)
            self.silverStanding.text = String(silverCount)
            self.goldStanding.text = String(goldCount)
        })
        //DISPLAY NUMBER OF EVENTS PER CATEGORY
        databaseHandle = ref?.child("Events").observe(.value, with: { (snapshot) in
            for case let rest as DataSnapshot in snapshot.children{
                if (rest.childSnapshot(forPath: "Category").value as! String == "Advancement"){
                    advCount += 1
                }
                else if (rest.childSnapshot(forPath: "Category").value as! String == "Fundraising"){
                    fundCount += 1
                }
                else if (rest.childSnapshot(forPath: "Category").value as! String == "Philanthropy"){
                    philCount += 1
                }
                else if (rest.childSnapshot(forPath: "Category").value as! String == "Professionalism"){
                    profCount += 1
                }
            }
            self.advEvents.text = String(advCount)
            self.fundEvents.text = String(fundCount)
            self.philEvents.text = String(philCount)
            self.profEvents.text = String(profCount)
        })
    }
}
