//
//  AdminLogInViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/25/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase

class AdminLogInViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var logo: UIImageView!
    
    @IBAction func backToMainLog(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func signIn(_ sender: Any) {
        guard let email = emailField.text else { return }
        guard let pass = passwordField.text else { return }
        
        if emailField.text == "executivevp.akpsi.calpoly@gmail.com" && passwordField.text == "pirho1998"
        {
            Auth.auth().signIn(withEmail: email, password: pass) { user, error in
                if error == nil && user != nil {
                    print("Admin logged in!")
                    self.performSegue(withIdentifier: "toAdminHome", sender: self)
                }
                else{
                    print("Error logging Admin in: \(error!.localizedDescription)")
                }
            }
        }
        else
        {
            let dialogMessage = UIAlertController(title: "Error Logging In", message: "Incorrect username or password", preferredStyle: .alert)
            // Create Cancel button with action handlder
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
                print("Cancel button tapped")
            }
            //Add OK and Cancel button to dialog message
            dialogMessage.addAction(cancel)
            // Present dialog message to user
            self.present(dialogMessage, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        logo.image = UIImage(named: "akp_lgo-1")
        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        passwordField.resignFirstResponder()
        emailField.resignFirstResponder()
    }
}
