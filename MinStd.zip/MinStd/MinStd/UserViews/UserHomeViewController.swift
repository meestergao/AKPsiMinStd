//
//  UserHomeViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/2/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import FirebaseDatabase

var eventIndex = 0
var eventsData = [Event]()


class UserHomeViewController: UIViewController {
    
    //OUTLETS
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func unwindToShiftHome(segue:UIStoryboardSegue){}
    
    //VARIABLES
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    var shifts = [[String]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        //SET FIREBASE REFERENCE
        ref = Database.database().reference()
        
        //RETRIEVE POSTS
        databaseHandle = ref?.child("Events").observe(.value, with: { (snapshot) in
            //CODE TO EXECUTE WHEN A CHILD IS ADDED UNDER "EVENTS"
            //ADD DATA TO eventsData array
            //Try to convert the value of the data to Event
            eventsData.removeAll()
            for case let rest as DataSnapshot in snapshot.children{
                self.shifts.removeAll()
                let testShifts = rest.childSnapshot(forPath: "/Shifts")
                let title = rest.key
                let cat = rest.childSnapshot(forPath: "/Category").value as! String
                let startTime = rest.childSnapshot(forPath: "/Start Time").value as! String
                let endTime = rest.childSnapshot(forPath: "/End Time").value as! String
                let date = rest.childSnapshot(forPath: "/Date").value as! String
                let shiftCap = rest.childSnapshot(forPath: "/Shift Cap").value as! String
                for x in testShifts.children{
                    let snap = x as! DataSnapshot
                    var nestedSnap = [String]()
                    nestedSnap.append(snap.key)
                    nestedSnap.append(snap.value as! String)
                    self.shifts.append(nestedSnap)
                }
                let event = Event(eventCat: cat, eventTitle: title, eventStartTime: startTime, eventEndTime: endTime, eventDate: date, eventShiftCap: shiftCap, shifts: self.shifts)
                eventsData.append(event)
            }
            //Append data to the table array eventsData
            self.tableView.reloadData()
        })
        
    }
}

extension UserHomeViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let eventtemp = eventsData[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCell", for:indexPath) as? EventCell
        cell?.setEvent(event: eventtemp)
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        eventIndex = indexPath.row
        performSegue(withIdentifier: "shiftsegue", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
