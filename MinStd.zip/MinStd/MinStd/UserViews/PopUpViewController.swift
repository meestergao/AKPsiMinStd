//
//  PopUpViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/24/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

let digitSet = CharacterSet.decimalDigits


class PopUpViewController: UIViewController {
    
    var tempInt: Int = 0
    
    //OUTLETS
    @IBOutlet weak var eventShiftTitle: UILabel!
    @IBOutlet weak var eventShiftDesc: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    
    //BUTTONS
    @IBAction func noCancel(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func confirmShift(_ sender: Any) {
        let ref = Database.database().reference()
        let shiftKey = eventsData[eventIndex].shifts[shiftIndex][0]
        let shiftSpots = eventsData[eventIndex].shifts[shiftIndex][1]
        //CHECK SHIFT CAPACITY
        if checkCapacity(spots: shiftSpots, capacity: eventsData[eventIndex].eventShiftCap) {
            //ADD SHIFT TO USER PROFILE
            let shift = ["Title": eventsData[eventIndex].eventTitle, "Category": eventsData[eventIndex].eventCat, "Date": eventsData[eventIndex].eventDate, "Time": eventsData[eventIndex].shifts[shiftIndex][0]]
            guard let uid = Auth.auth().currentUser?.uid else {return}
            ref.child("Users").child(uid).child("Shifts").child(eventsData[eventIndex].eventTitle + " " + eventsData[eventIndex].shifts[shiftIndex][0]).setValue(shift)
            //UPDATE SHIFT INFO WITH USER
            let newShiftSpots = updateSpots(spots: shiftSpots)
            ref.child("Events").child(eventsData[eventIndex].eventTitle).child("Shifts").child(shiftKey).setValue(newShiftSpots)
            dismiss(animated: true)
        }
        else {
            errorLabel.text = "The shift is full"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        eventShiftTitle.text = eventsData[eventIndex].eventTitle
        //TODO ADD UID->USERNAME
        eventShiftDesc.text = "Spots: " + eventsData[eventIndex].shifts[shiftIndex][1] + "  " + eventsData[eventIndex].shifts[shiftIndex][0]
    }
    
    func updateSpots(spots: String) -> String {
        var temp: String = ""
        let cap = eventsData[eventIndex].eventShiftCap
        for x in spots.unicodeScalars{
            if digitSet.contains(x) {
                temp = temp + String(x)
            }
            else {
                tempInt = Int(temp)! + 1
                temp = String(tempInt)
                break
            }
        }
        temp = temp + " / " + cap
        return temp
    }
    
    func checkCapacity(spots: String, capacity: String) -> Bool {
        var temp: String = ""
        for x in spots.unicodeScalars{
            if digitSet.contains(x){
                temp = temp + String(x)
            }
            else {
                tempInt = Int(temp)!
                if tempInt < Int(capacity)! {
                    return true
                }
            }
        }
        return false
    }
}
