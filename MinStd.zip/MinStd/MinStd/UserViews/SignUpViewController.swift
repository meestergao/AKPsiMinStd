//
//  SignUpViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/25/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class SignUpViewController: UIViewController {
    
    let ref = Database.database().reference()
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var logo: UIImageView!
    
    @IBAction func backToMain(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func signUp(_ sender: Any) {
        guard let username = usernameField.text else { return }
        guard let email = emailField.text else { return }
        guard let pass = passwordField.text else { return }
        
        Auth.auth().createUser(withEmail: email, password: pass) { user, error in
            if error == nil && user != nil
            {
                print("User created!")
                let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = username
                changeRequest?.commitChanges { error in
                    if error == nil {
                        print("User display name changed!")
                        //USER ENTITY
                        let newUser = ["Username": self.usernameField.text!, "Email": self.emailField.text!]
                        //ADD USER TO DATABASE
                        guard let uid = Auth.auth().currentUser?.uid else { return }
                        self.ref.child("Users").child(uid).setValue(newUser)
                        let hours = ["Professionalism": "0", "Philanthropy": "0", "Advancement": "0", "Fundraising": "0", "Miscellaneous": "0"]
                        self.ref.child("Users").child(uid).child("Hours").setValue(hours)
                        self.dismiss(animated: false, completion: nil)
                    }
                }
            }
            else
            {
                print("Error creating user: \(error!.localizedDescription)")
                let dialogMessage = UIAlertController(title: "Error Signing Up", message: error!.localizedDescription, preferredStyle: .alert)
                // Create Cancel button with action handlder
                let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
                    print("Cancel button tapped")
                }
                //Add OK and Cancel button to dialog message
                dialogMessage.addAction(cancel)
                // Present dialog message to user
                self.present(dialogMessage, animated: true, completion: nil)
            }
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        logo.image = UIImage(named: "akp_lgo-1")
        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        usernameField.resignFirstResponder()
        passwordField.resignFirstResponder()
        emailField.resignFirstResponder()
    }

}
