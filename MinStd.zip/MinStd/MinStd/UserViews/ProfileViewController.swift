//
//  ProfileViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/25/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ProfileViewController: UIViewController {
    //OUTLETS
    @IBOutlet weak var usernameField: UILabel!
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var profile: UITableView!
    @IBOutlet weak var standing: UITextField!
    @IBOutlet weak var nextStanding: UITextField!
    @IBOutlet weak var advHoursNeeded: UITextField!
    @IBOutlet weak var fundHoursNeeded: UITextField!
    @IBOutlet weak var miscHoursNeeded: UITextField!
    @IBOutlet weak var philHoursNeeded: UITextField!
    @IBOutlet weak var profHoursNeeded: UITextField!
    @IBAction func logout(_ sender: Any) {
        try! Auth.auth().signOut()
    }
    
    //VARIABLES
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    var profileStats = [Hours]()
    var temp:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profile.delegate = self
        profile.dataSource = self
        //SET FIREBASE REFERENCE
        guard let uid = Auth.auth().currentUser?.uid else {return}
        ref = Database.database().reference()
        //DISPLAY CURRENT USERNAME
        ref?.child("Users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            self.navBar.topItem?.title = snapshot.childSnapshot(forPath: "/Username").value as? String
        })
        //DISPLAY HOURS
        databaseHandle = ref?.child("Users").child(uid).child("Hours").observe(.value, with: { (snapshot) in
            self.profileStats.removeAll()
            for case let rest as DataSnapshot in snapshot.children{
                let category = rest.key
                let earned = rest.value as! String
                let hours = Hours(category: category, earned: earned)
                self.profileStats.append(hours)
            }
            self.profile.reloadData()
            //CALCULATE CURRENT AND NEXT STANDING
            self.calcStanding()
        })
    }
    
    func nextAchievableStanding(stand: String){
        print(stand)
        if (stand == "Bad Standing"){
            nextStanding.text = "Bronze Standing"
        }
        else if (stand == "Bronze Standing"){
            nextStanding.text = "Silver Standing"
        }
        else if (stand == "Silver Standing"){
            nextStanding.text = "Gold Standing"
        }
        else if (stand == "Gold Standing"){
            nextStanding.text = "Gold Achieved!"
        }
        else{
            nextStanding.text = "ERROR"
        }
    }
    
    func calcStanding(){
        ref?.child("Standards").observeSingleEvent(of: .value, with: {(snapshot) in
            guard let uid = Auth.auth().currentUser?.uid else {return}
            let bronzeAdv = snapshot.childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Advancement").value as? String
            let bronzeProf = snapshot.childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Professionalism").value as? String
            let bronzePhil = snapshot.childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Philanthropy").value as? String
            let bronzeFund = snapshot.childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Fundraising").value as? String
            let bronzeExtra = snapshot.childSnapshot(forPath: "Bronze").childSnapshot(forPath: "Extra").value as? String
            let silverProf = snapshot.childSnapshot(forPath: "Silver").childSnapshot(forPath: "Professionalism").value as? String
            let silverPhil = snapshot.childSnapshot(forPath: "Silver").childSnapshot(forPath: "Philanthropy").value as? String
            let silverAdv = snapshot.childSnapshot(forPath: "Silver").childSnapshot(forPath: "Advancement").value as? String
            let silverFund = snapshot.childSnapshot(forPath: "Silver").childSnapshot(forPath: "Fundraising").value as? String
            let silverExtra = snapshot.childSnapshot(forPath: "Silver").childSnapshot(forPath: "Extra").value as? String
            let goldProf = snapshot.childSnapshot(forPath: "Gold").childSnapshot(forPath: "Professionalism").value as? String
            let goldPhil = snapshot.childSnapshot(forPath: "Gold").childSnapshot(forPath: "Philanthropy").value as? String
            let goldAdv = snapshot.childSnapshot(forPath: "Gold").childSnapshot(forPath: "Advancement").value as? String
            let goldFund = snapshot.childSnapshot(forPath: "Gold").childSnapshot(forPath: "Fundraising").value as? String
            let goldExtra = snapshot.childSnapshot(forPath: "Gold").childSnapshot(forPath: "Extra").value as? String
            //CHECK IF BAD STANDING
            if (self.calcBBSG(adv: Int(bronzeAdv!)!, ext: Int(bronzeExtra!)!, fund: Int(bronzeFund!)!, phil: Int(bronzePhil!)!, prof: Int(bronzeProf!)!)){
                self.standing.text = "Bad Standing"
                self.temp = "Bad Standing"
                self.nextAchievableStanding(stand: self.temp)
                self.ref?.child("Users").child(uid).child("Standing").setValue(self.temp)
            }
            else{
                if (self.calcBBSG(adv: Int(silverAdv!)!, ext: Int(silverExtra!)!, fund: Int(silverFund!)!, phil: Int(silverPhil!)!, prof: Int(silverProf!)!)){
                    self.standing.text = "Bronze Standing"
                    self.temp = "Bronze Standing"
                }
                else{
                    if (self.calcBBSG(adv: Int(goldAdv!)!, ext: Int(goldExtra!)!, fund: Int(goldFund!)!, phil: Int(goldPhil!)!, prof: Int(goldProf!)!)){
                        self.standing.text = "Silver Standing"
                        self.temp = "Silver Standing"
                    }
                    else{
                        self.standing.text = "Gold Standing"
                        self.temp = "Gold Standing"
                        self.advHoursNeeded.text = "0"
                        self.miscHoursNeeded.text = "0"
                        self.fundHoursNeeded.text = "0"
                        self.philHoursNeeded.text = "0"
                        self.profHoursNeeded.text = "0"
                    }
                }
                self.nextAchievableStanding(stand: self.temp)
                self.ref?.child("Users").child(uid).child("Standing").setValue(self.temp)
            }
        })
    }
    
    func calcBBSG(adv: Int, ext: Int, fund: Int, phil: Int, prof: Int) -> Bool{
        if (Int(self.profileStats[0].earned)! < adv || Int(self.profileStats[2].earned)! < ext || Int(self.profileStats[1].earned)! < fund || Int(self.profileStats[3].earned)! < phil || Int(self.profileStats[4].earned)! < prof){
            if (Int(self.profileStats[0].earned)! < adv){
                advHoursNeeded.text = String(adv - Int(self.profileStats[0].earned)!)
            }
            else{
                advHoursNeeded.text = "0"
            }
            if (Int(self.profileStats[2].earned)! < ext){
                miscHoursNeeded.text = String(ext - Int(self.profileStats[2].earned)!)
            }
            else{
                miscHoursNeeded.text = "0"
            }
            if (Int(self.profileStats[1].earned)! < fund){
                fundHoursNeeded.text = String(fund - Int(self.profileStats[1].earned)!)
            }
            else{
                fundHoursNeeded.text = "0"
            }
            if (Int(self.profileStats[3].earned)! < phil){
                philHoursNeeded.text = String(phil - Int(self.profileStats[3].earned)!)
            }
            else{
                philHoursNeeded.text = "0"
            }
            if (Int(self.profileStats[4].earned)! < prof){
                profHoursNeeded.text = String(prof - Int(self.profileStats[4].earned)!)
            }
            else{
                profHoursNeeded.text = "0"
            }
            return true
        }
        else{
            return false
        }
    }
}

extension ProfileViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return profileStats.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let temp = profileStats[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProfileCell", for:indexPath) as? ProfileCell
        cell?.setCell(title: temp.category, hours: temp.earned)
        return cell!
    }
}
