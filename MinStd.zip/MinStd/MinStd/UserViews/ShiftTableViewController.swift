//
//  TableViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/13/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit

//VARIABLES
var shiftIndex = 0

class ShiftTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    //OUTLETS
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var shiftLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier: "back", sender: self)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    
        //WRITE TITLE LABEL
        shiftLabel.text = eventsData[eventIndex].eventCat + ": " + eventsData[eventIndex].eventTitle
        dateLabel.text = eventsData[eventIndex].eventDate
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventsData[eventIndex].shifts.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let eventtemp = eventsData[eventIndex].shifts[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier:"ShiftCell", for:indexPath) as? ShiftCell
        cell?.setShift(time: eventtemp[0], spots: eventtemp[1])
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        shiftIndex = indexPath.row
        performSegue(withIdentifier: "confirmShiftSegue", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
