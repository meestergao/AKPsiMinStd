//
//  PersonalShiftsViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/26/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

var personalShifts = [Shift]()

class PersonalShiftsViewController: UIViewController {

    //OUTLETS
    @IBOutlet weak var tableViewPersonal: UITableView!
    
    //VARIABLES
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    var temp = ""
    var tempInt = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewPersonal.delegate = self
        tableViewPersonal.dataSource = self
        //SET FIREBASE REFERENCE
        guard let uid = Auth.auth().currentUser?.uid else {return}
        ref = Database.database().reference()
        //RETRIEVE SHIFTS
        databaseHandle = ref?.child("Users").child(uid).child("Shifts").observe(.value, with: { (snapshot) in
            personalShifts.removeAll()
            for case let rest as DataSnapshot in snapshot.children{
                let title = rest.childSnapshot(forPath: "/Title").value as! String
                let category = rest.childSnapshot(forPath: "/Category").value as! String
                let date = rest.childSnapshot(forPath: "/Date").value as! String
                let time = rest.childSnapshot(forPath: "/Time").value as! String
                let shift = Shift(title: title, category: category, date: date, time: time)
                personalShifts.append(shift)
            }
            self.tableViewPersonal.reloadData()
        })
    }
}

extension PersonalShiftsViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personalShifts.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let shifttemp = personalShifts[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "PersonalShiftCell", for:indexPath) as? PersonalShiftCell
        cell?.setShift(title: shifttemp.category + ": " + shifttemp.title, time: shifttemp.time)
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        shiftIndex = indexPath.row
        performSegue(withIdentifier: "logShift", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    //DELETE SHIFTS
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = deleteShift(path: indexPath)
        return UISwipeActionsConfiguration(actions: [delete])
    }
    func deleteShift(path: IndexPath) -> UIContextualAction{
        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completion) in
            let uid = Auth.auth().currentUser?.uid
            let shiftKey = personalShifts[path.row].time
            self.ref?.child("Events").child(personalShifts[path.row].title).child("Shifts").observeSingleEvent(of: .value, with: { (snapshot) in
                let shiftSpots = snapshot.childSnapshot(forPath: "/" + shiftKey).value as! String
                let newShiftSpots = self.decrementSpots(spots: shiftSpots)
                self.ref?.child("Events").child(personalShifts[path.row].title).child("Shifts").child(personalShifts[path.row].time).setValue(newShiftSpots)
            })
            self.ref?.child("Users").child(uid!).child("Shifts").child(personalShifts[path.row].title + " " + shiftKey).removeValue()
            personalShifts.remove(at: path.row)
            self.tableViewPersonal.deleteRows(at: [path], with: .automatic)
            completion(true)
        }
        action.backgroundColor = .red
        return action
    }
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .normal, title: "TEST") { (action, view, nil) in
            print("TEST")
        }
        return UISwipeActionsConfiguration(actions: [action])
    }
    
    func decrementSpots(spots: String) -> String
    {
        temp = ""
        tempInt = 0
        let cap = eventsData[eventIndex].eventShiftCap
        for x in spots.unicodeScalars{
            if digitSet.contains(x){
                temp = temp + String(x)
            }
            else
            {
                tempInt = Int(temp)! - 1
                temp = String(tempInt)
                break
            }
        }
        temp = temp + " / " + cap
        return temp
    }
}
