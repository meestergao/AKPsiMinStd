//
//  MainMenuViewController.swift
//  MinStd
//
//  Created by Chris Gao on 3/25/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase

class MainMenuViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    @IBAction func goToSignUp(_ sender: Any) {
        self.performSegue(withIdentifier: "showSignUp", sender: self)
    }
    @IBAction func goToUserLogIn(_ sender: Any) {
        self.performSegue(withIdentifier: "showUserLogin", sender: self)
    }
    @IBAction func goToAdminLogIn2(_ sender: Any) {
        self.performSegue(withIdentifier: "showAdminLogIn", sender: self)
    }
    @IBAction func goToAdminLogIn(_ sender: Any) {
        self.performSegue(withIdentifier: "showAdminLogIn", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        logo.image = UIImage(named: "akp_lgo-1")
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if (Auth.auth().currentUser != nil && (Auth.auth().currentUser?.email == "executivevp.akpsi.calpoly@gmail.com")){
            self.performSegue(withIdentifier: "toAdminHome", sender: self)
        }
        else if Auth.auth().currentUser != nil {
            self.performSegue(withIdentifier: "toUserHome", sender: self)
        }
    }
}
