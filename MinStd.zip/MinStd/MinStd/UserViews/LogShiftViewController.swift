//
//  LogShiftViewController.swift
//  MinStd
//
//  Created by Chris Gao on 4/7/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class LogShiftViewController: UIViewController {

    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    
    //VARIABLES
    var ref:DatabaseReference?
    var databaseHandle: DatabaseHandle?
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func confirm(_ sender: Any) {
        ref = Database.database().reference()
        let cat = personalShifts[shiftIndex].category
        guard let uid = Auth.auth().currentUser?.uid else {return}
        if (cat == "Professionalism"){
            ref?.child("Users").child(uid).child("Hours").child("Professionalism").observeSingleEvent(of: .value, with: { (snapshot) in
                let temp = snapshot.value as! String
                let new = self.updateHours(hours: temp)
                self.ref?.child("Users").child(uid).child("Hours").child("Professionalism").setValue(new)
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        else if (cat == "Philanthropy"){
            ref?.child("Users").child(uid).child("Hours").child("Philanthropy").observe(.value, with: { (snapshot) in
                let temp = snapshot.value as! String
                let new = self.updateHours(hours: temp)
                self.ref?.child("Users").child(uid).child("Hours").child("Philanthropy").setValue(new)
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        else if (cat == "Advancement"){
            ref?.child("Users").child(uid).child("Hours").child("Advancement").observeSingleEvent(of: .value, with: { (snapshot) in
                let temp = snapshot.value as! String
                let new = self.updateHours(hours: temp)
                self.ref?.child("Users").child(uid).child("Hours").child("Advancement").setValue(new)
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        else if (cat == "Fundraising"){
            ref?.child("Users").child(uid).child("Hours").child("Fundraising").observeSingleEvent(of: .value, with: { (snapshot) in
                let temp = snapshot.value as! String
                let new = self.updateHours(hours: temp)
                self.ref?.child("Users").child(uid).child("Hours").child("Fundraising").setValue(new)
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        else{
            ref?.child("Users").child(uid).child("Hours").child("Miscellaneous").observeSingleEvent(of: .value, with: { (snapshot) in
                let temp = snapshot.value as! String
                let new = self.updateHours(hours: temp)
                self.ref?.child("Users").child(uid).child("Hours").child("Miscellaneous").setValue(new)
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        deleteShift()
        dismiss(animated: true)
    }
    
    func deleteShift(){
        let uid = Auth.auth().currentUser?.uid
        let shiftKey = personalShifts[shiftIndex].time
        self.ref?.child("Events").child(personalShifts[shiftIndex].title).child("Shifts").observeSingleEvent(of: .value, with: { (snapshot) in
            self.ref?.child("Users").child(uid!).child("Shifts").child(personalShifts[shiftIndex].title + " " + shiftKey).removeValue()
            personalShifts.remove(at: shiftIndex)
            })
    }
    
    func updateHours(hours: String) -> String{
        var a:Int! = Int(hours)
        a = a + 1
        let b:String! = String(a)
        return b
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = personalShifts[shiftIndex].title
        descLabel.text = personalShifts[shiftIndex].date + "\n" + personalShifts[shiftIndex].time
        let calendar = Calendar.current
        let dateFormatter = DateFormatter()
        let dateString = personalShifts[shiftIndex].date
        dateFormatter.dateFormat = "mm/dd/yyyy"
        let date = dateFormatter.date(from: dateString)!
        if (!calendar.isDateInToday(date) && !calendar.isDateInTomorrow(date))
        {
//            errorLabel.text = "You can not check in to your shift yet"
        }
        else
        {
            //confirm call and let user log hours
        }
    }

}
