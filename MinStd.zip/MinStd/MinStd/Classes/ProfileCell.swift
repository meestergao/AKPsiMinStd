//
//  ProfileCell.swift
//  MinStd
//
//  Created by Chris Gao on 5/4/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var hoursLabel: UILabel!
    
    func setCell(title: String, hours: String){
        titleLabel.text = title
        hoursLabel.text = hours
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
