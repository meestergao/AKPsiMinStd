//
//  ShiftCell.swift
//  MinStd
//
//  Created by Chris Gao on 3/14/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit

class ShiftCell: UITableViewCell {
    
    //OUTLETS
    @IBOutlet weak var shiftLabel: UILabel!
    @IBOutlet weak var shiftSpots: UILabel!
    
    func setShift(time: String, spots: String){
        shiftLabel.text = time
        shiftSpots.text = spots
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
