//
//  GradientView.swift
//  MinStd
//
//  Created by Chris Gao on 3/1/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit

@IBDesignable
class GradientView: UIView {

    @IBInspectable var firstColor: UIColor = UIColor.clear {
        didSet{
            updateView()
        }
    }
    @IBInspectable var secondColor: UIColor = UIColor.clear {
        didSet{
            updateView()
        }
    }

    override class var layerClass: AnyClass{
        get{
            return CAGradientLayer.self
        }
    }
    
    func updateView(){
        let layer = self.layer as! CAGradientLayer
        layer.colors = [ firstColor.cgColor , secondColor.cgColor ]
    }
}
