//
//  Event.swift
//  MinStd
//
//  Created by Chris Gao on 2/28/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import Foundation

class Event{
    
    var eventCat: String
    var eventTitle: String
    var eventStartTime: String
    var eventEndTime: String
    var eventDate: String
    var eventShiftCap: String
    var shifts: [[String]]
    
    init(eventCat: String, eventTitle: String, eventStartTime: String, eventEndTime: String, eventDate: String, eventShiftCap: String, shifts: [[String]]) {
        self.eventCat = eventCat
        self.eventTitle = eventTitle
        self.eventStartTime = eventStartTime
        self.eventEndTime = eventEndTime
        self.eventDate = eventDate
        self.eventShiftCap = eventShiftCap
        self.shifts = shifts
    }
}
