//
//  EventCellTableViewCell.swift
//  MinStd
//
//  Created by Chris Gao on 2/28/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import UIKit

class EventCell: UITableViewCell {

    
    @IBOutlet weak var eventLabelView: UILabel!
    @IBOutlet weak var timeLabelView: UILabel!
    
    func setEvent(event: Event) {
        eventLabelView.text = event.eventCat + ": " + event.eventTitle
        timeLabelView.text = event.eventDate + "  " + event.eventStartTime + " - " + event.eventEndTime
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
