//
//  Shift.swift
//  MinStd
//
//  Created by Chris Gao on 3/26/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import Foundation

class Shift{
    
    var title: String
    var category: String
    var date: String
    var time: String
    
    init(title: String, category: String, date: String, time: String) {
        self.title = title
        self.category = category
        self.date = date
        self.time = time
    }
}
