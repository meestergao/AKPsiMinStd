//
//  PersonalShiftCell.swift
//  MinStd
//
//  Created by Chris Gao on 3/26/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//
import UIKit

class PersonalShiftCell: UITableViewCell {
    
    //OUTLETS
    @IBOutlet weak var shiftTitleField: UILabel!
    @IBOutlet weak var shiftTimeField: UILabel!
    
    func setShift(title: String, time: String){
        shiftTitleField.text = title
        shiftTimeField.text = time
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
