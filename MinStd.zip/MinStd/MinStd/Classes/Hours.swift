//
//  Hours.swift
//  MinStd
//
//  Created by Chris Gao on 5/5/19.
//  Copyright © 2019 Chris Gao. All rights reserved.
//

import Foundation

class Hours{
    var category: String
    var earned: String
    
    init(category: String, earned: String) {
        self.category = category
        self.earned = earned
    }
}
